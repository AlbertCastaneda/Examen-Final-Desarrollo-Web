
const express = require('express');
const bodyParser = require('body-parser');
const methodOverride = require('method-override');
const path = require('path');
const { nanoid } = require('nanoid');
const store = require('./data/store');

const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(methodOverride('_method'));

// Navbar pages
app.get('/', (req, res) => {
  res.render('index', { page:'inicio' });
});
app.get('/contacto', (req, res) => {
  res.render('contacto', { page:'contacto' });
});
app.get('/creditos', (req, res) => {
  res.render('creditos', { page:'creditos' });
});

// CATEGORÍAS
app.get('/categorias', (req, res) => {
  const categorias = store.getCategorias();
  res.render('categorias/list', { page:'categorias', categorias });
});

app.get('/categorias/nuevo', (req, res) => {
  res.render('categorias/form', { page:'categorias', mode:'crear', categoria:{ nombre:'', descripcion:'' } });
});

app.post('/categorias', (req, res) => {
  const { nombre, descripcion } = req.body;
  const id = 'cat-' + nanoid(6);
  store.addCategoria({ id, nombre, descripcion });
  res.redirect('/categorias');
});

app.get('/categorias/:id/editar', (req, res) => {
  const categoria = store.getCategoria(req.params.id);
  if (!categoria) return res.status(404).send('Categoría no encontrada');
  res.render('categorias/form', { page:'categorias', mode:'editar', categoria });
});

app.post('/categorias/:id', (req, res) => {
  const { nombre, descripcion } = req.body;
  store.updateCategoria(req.params.id, { nombre, descripcion });
  res.redirect('/categorias');
});

// PRODUCTOS
app.get('/productos', (req, res) => {
  const { filtroCategoria, filtroEquipo, q } = req.query;
  let productos = store.getProductos().map(p => ({
    ...p,
    categoriaNombre: (store.getCategoria(p.categoriaId) || {}).nombre || 'Sin categoría'
  }));

  if (filtroCategoria) productos = productos.filter(p => p.categoriaId === filtroCategoria);
  if (filtroEquipo) productos = productos.filter(p => p.equipo === filtroEquipo);
  if (q) {
    const s = q.toLowerCase();
    productos = productos.filter(p =>
      (p.nombre || '').toLowerCase().includes(s) ||
      (p.descripcion || '').toLowerCase().includes(s)
    );
  }

  res.render('productos/list', {
    page:'productos',
    productos,
    categorias: store.getCategorias(),
    equipos: store.getEquipos(),
    filtroCategoria, filtroEquipo, q
  });
});

app.get('/productos/nuevo', (req, res) => {
  res.render('productos/form', {
    page:'productos',
    mode:'crear',
    producto:{ nombre:'', precio:'', categoriaId:'', descripcion:'', equipo:'' },
    categorias: store.getCategorias(),
    equipos: store.getEquipos()
  });
});

app.post('/productos', (req, res) => {
  const { nombre, precio, categoriaId, equipo, descripcion } = req.body;
  const id = 'prd-' + nanoid(6);
  const precioNum = parseFloat(precio || 0);
  store.addProducto({ id, nombre, precio:precioNum, categoriaId, equipo, descripcion });
  res.redirect('/productos');
});

app.get('/productos/:id/editar', (req, res) => {
  const producto = store.getProducto(req.params.id);
  if (!producto) return res.status(404).send('Producto no encontrado');
  res.render('productos/form', {
    page:'productos',
    mode:'editar',
    producto,
    categorias: store.getCategorias(),
    equipos: store.getEquipos()
  });
});

app.post('/productos/:id', (req, res) => {
  const { nombre, precio, categoriaId, equipo, descripcion } = req.body;
  const precioNum = parseFloat(precio || 0);
  store.updateProducto(req.params.id, { nombre, precio:precioNum, categoriaId, equipo, descripcion });
  res.redirect('/productos');
});

// 404
app.use((req, res) => {
  res.status(404).render('404', { page:'' });
});

app.listen(PORT, () => {
  console.log(`Servidor iniciado en http://localhost:${PORT}`);
});
