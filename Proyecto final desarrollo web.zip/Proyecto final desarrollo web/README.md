
# Tienda F1 - Examen (UMG)

Tienda de **merch de Fórmula 1** con categorías y productos:
- Equipos: **Red Bull, McLaren, Mercedes, Ferrari**
- Categorías: **Camisas, Zapatos, Funkos, Carritos a escala, Chumpas, Sudaderos, Gorras**
- CRUD parcial: listar, **agregar** y **editar** (categorías y productos)
- Filtros por **categoría**, **equipo** y **búsqueda**

## Páginas
- `/` Inicio
- `/categorias` Listar / agregar / editar
- `/productos` Listar / agregar / editar + filtros
- `/contacto` Información de contacto
- `/creditos` Datos UMG (nombre, carné, curso)

## Ejecutar local
```bash
npm install
npm start
# abrir http://localhost:3000
```

## Estructura
server.js, views (EJS), public/css/style.css, data/db.json, data/store.js, package.json
