
const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'db.json');

function load() {
  if (!fs.existsSync(DB_PATH)) {
    const initial = seed();
    fs.writeFileSync(DB_PATH, JSON.stringify(initial, null, 2));
    return initial;
  }
  const raw = fs.readFileSync(DB_PATH, 'utf-8');
  return JSON.parse(raw);
}

function seed() {
  const categorias = [
    { id:"cat-camisas", nombre:"Camisas", descripcion:"Playeras y camisetas oficiales" },
    { id:"cat-zapatos", nombre:"Zapatos", descripcion:"Calzado temático F1" },
    { id:"cat-funkos", nombre:"Funkos", descripcion:"Figuras coleccionables" },
    { id:"cat-carritos", nombre:"Carritos a escala", descripcion:"Modelos 1:18 / 1:43" },
    { id:"cat-chumpas", nombre:"Chumpas", descripcion:"Chaquetas de equipos" },
    { id:"cat-sudaderos", nombre:"Sudaderos", descripcion:"Hoodies y suéteres" },
    { id:"cat-gorras", nombre:"Gorras", descripcion:"Caps oficiales" }
  ];
  const equipos = ["Red Bull", "McLaren", "Mercedes", "Ferrari"];
  const productos = [
    { id:"prd-1", nombre:"Camisa Red Bull 2025", precio:299.00, categoriaId:"cat-camisas", equipo:"Red Bull", descripcion:"Camisa oficial temporada 2025" },
    { id:"prd-2", nombre:"Gorra Ferrari Scuderia", precio:199.00, categoriaId:"cat-gorras", equipo:"Ferrari", descripcion:"Gorra curva con escudo bordado" },
    { id:"prd-3", nombre:"Funko Max #1", precio:149.00, categoriaId:"cat-funkos", equipo:"Red Bull", descripcion:"Figura coleccionable piloto" },
    { id:"prd-4", nombre:"Carrito McLaren MCL60 1:18", precio:999.00, categoriaId:"cat-carritos", equipo:"McLaren", descripcion:"Modelo a escala premium" },
    { id:"prd-5", nombre:"Sudadero Mercedes AMG", precio:449.00, categoriaId:"cat-sudaderos", equipo:"Mercedes", descripcion:"Hoodie con logo AMG" },
    { id:"prd-6", nombre:"Chumpa Ferrari Team", precio:799.00, categoriaId:"cat-chumpas", equipo:"Ferrari", descripcion:"Chaqueta ligera oficial" },
    { id:"prd-7", nombre:"Zapatos McLaren Street", precio:599.00, categoriaId:"cat-zapatos", equipo:"McLaren", descripcion:"Sneakers edición limitada" }
  ];
  return { categorias, productos, equipos };
}

function save(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

let cache = load();

module.exports = {
  all: () => cache,
  getCategorias: () => cache.categorias,
  getProductos: () => cache.productos,
  getEquipos: () => cache.equipos || ["Red Bull","McLaren","Mercedes","Ferrari"],
  getCategoria: (id) => cache.categorias.find(c => c.id === id),
  getProducto: (id) => cache.productos.find(p => p.id === id),
  addCategoria: (cat) => { cache.categorias.push(cat); save(cache); },
  updateCategoria: (id, payload) => {
    const idx = cache.categorias.findIndex(c => c.id === id);
    if (idx >= 0) { cache.categorias[idx] = { ...cache.categorias[idx], ...payload }; save(cache); }
  },
  addProducto: (prod) => { cache.productos.push(prod); save(cache); },
  updateProducto: (id, payload) => {
    const idx = cache.productos.findIndex(p => p.id === id);
    if (idx >= 0) { cache.productos[idx] = { ...cache.productos[idx], ...payload }; save(cache); }
  }
};
